import React from 'react';

import DisplayAllPosts from './DisplayAllPosts';

const Profile = () => {
  const { isAuthenticated } = Login();

  return (
    isAuthenticated && ( 
    <>
      <DisplayAllPosts />
    </>    
    
    
    )
    
  )
}

export default Profile