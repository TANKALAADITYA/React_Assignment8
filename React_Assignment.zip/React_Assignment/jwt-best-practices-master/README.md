## JWT Best Practices

This is the source repository for a tutorial on the best practices for JWT client side authentication.

### Setup

1. Clone this repository: `git clone https://github.com/bahdcoder/jwt-best-practices.git`
2. Install packages for API and start API: `cd /api && yarn && yarn start`
3. Install packages for client and start client: `cd /client && yarn && yarn start`
